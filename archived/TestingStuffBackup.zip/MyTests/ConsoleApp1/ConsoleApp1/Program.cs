﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;

Console.WriteLine("Hello, World!");

var psi = new ProcessStartInfo
{
    UseShellExecute = true,
    FileName = "notepad.exe",
};


Process.Start(psi);

while (true)
{
    await Task.Delay(1000);
    Console.WriteLine("...");
}