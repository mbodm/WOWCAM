﻿namespace WOWCAM.Core
{
    public interface IConfigValidator
    {
        void Validate();
    }
}
