﻿namespace WOWCAM.Core
{
    public sealed record ModelAddonDownloadUrlData(
        string DownloadUrl,
        string FileName);
}
