﻿namespace WOWCAM.Helper
{
    public interface IGitHubHelper
    {
        Task<ModelGitHubLatestReleaseData> GetLatestReleaseData(CancellationToken cancellationToken = default);
    }
}
