﻿namespace WOWCAM.Helper
{
    public readonly struct ModelAddonPageJson
    {
        public ModelAddonPageJson(ulong projectId, string projectName, string projectSlug, ulong fileId, string fileName, ulong fileSize)
        {
            ProjectId = projectId;
            ProjectName = projectName;
            ProjectSlug = projectSlug;
            FileId = fileId;
            FileName = fileName;
            FileSize = fileSize;
        }

        public ulong ProjectId { get; }
        public string ProjectName { get; }
        public string ProjectSlug { get; }
        public ulong FileId { get; }
        public string FileName { get; }
        public ulong FileSize { get; }
    }
}
