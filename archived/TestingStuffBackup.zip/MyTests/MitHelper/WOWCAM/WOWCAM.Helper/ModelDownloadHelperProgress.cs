﻿namespace WOWCAM.Helper
{
    public readonly struct ModelDownloadHelperProgress
    {
        public ModelDownloadHelperProgress(string url, bool isPreDownloadSizeDetermination, long totalBytes, long receivedBytes)
        {
            Url = url;
            IsPreDownloadSizeDetermination = isPreDownloadSizeDetermination;
            TotalBytes = totalBytes;
            ReceivedBytes = receivedBytes;
        }

        public string Url { get; }
        public bool IsPreDownloadSizeDetermination { get; }
        public long TotalBytes { get; }
        public long ReceivedBytes { get; }
    }
}
