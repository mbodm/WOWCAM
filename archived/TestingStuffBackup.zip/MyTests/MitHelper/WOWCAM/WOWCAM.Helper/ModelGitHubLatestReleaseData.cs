﻿using System;

namespace WOWCAM.Helper
{
    public readonly struct ModelGitHubLatestReleaseData
    {
        public ModelGitHubLatestReleaseData(Version version, string downloadUrl, string fileName)
        {
            Version = version;
            DownloadUrl = downloadUrl;
            FileName = fileName;
        }

        public Version Version { get; }
        public string DownloadUrl { get; }
        public string FileName { get; }
    }
}
