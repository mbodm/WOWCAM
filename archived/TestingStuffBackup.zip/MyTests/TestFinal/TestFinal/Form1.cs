using System.Drawing;
using System.Windows.Forms;

namespace TestFinal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, System.EventArgs e)
        {
            BackColor = SystemColors.Window;
            linkLabel1.LinkColor = SystemColors.HotTrack;
            linkLabel1.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel1.Text = "Status des Computers �berpr�fen";

            Font = new Font("Segoe UI", 9);
        }
    }
}
