namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BackColor = SystemColors.Window;

            linkLabel1.Text = "Status des Computers �berpr�fen";
            linkLabel1.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel1.LinkColor = SystemColors.Highlight;

            linkLabel2.Text = "Status des Computers �berpr�fen";
            linkLabel2.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel2.LinkColor = SystemColors.MenuHighlight;

            linkLabel3.Text = "Status des Computers �berpr�fen";
            linkLabel3.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel3.LinkColor = SystemColors.HotTrack;
        }
    }
}
