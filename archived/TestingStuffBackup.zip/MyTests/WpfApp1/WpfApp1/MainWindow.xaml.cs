﻿using System.Diagnostics;
using System.IO;
using System.Windows;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var file = Path.Combine(AppContext.BaseDirectory, "ConsoleApp1.exe");
                if (!File.Exists(file)) throw new InvalidOperationException("Console app not exists.");

                var psi = new ProcessStartInfo { FileName = file, UseShellExecute = true };
                var p = Process.Start(psi);
                if (p != null) throw new InvalidOperationException("Process returned null.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
