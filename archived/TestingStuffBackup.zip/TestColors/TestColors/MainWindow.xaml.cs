﻿using System.Windows;

namespace TestColors
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var ci = Helper.Convert(System.Drawing.SystemColors.HotTrack);

            MessageBox.Show(ci.Dez);
        }
    }

    public record ColorInfo(byte Dez_R, byte Dez_G, byte Dez_B, string Dez, string Hex_R, string Hex_G, string Hex_B, string Hex);

    public static class Helper
    {
        public static ColorInfo Convert(System.Drawing.Color c) => new(c.R, c.G, c.B, $"{c.R} {c.G} {c.B}", $"{c.R:X2}", $"{c.G:X2}", $"{c.B:X2}", $"{c.R:X2} {c.G:X2} {c.B:X2}");
    }
}
