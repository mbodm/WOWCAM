﻿using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using FinalPrototyping.WebView;
using WOWCAM.Core;
using WOWCAM.Helper;
using WOWCAM.WebView;

namespace FinalPrototyping
{
    public partial class MainWindow : Window
    {
        private readonly ILogger logger = new DefaultLogger();

        private readonly IWebViewProvider webViewProvider;
        private readonly IWebViewConfigurator webViewConfigurator;
        private readonly ICurseScraper curseScraper;
        private readonly IWebViewDownloader webViewDownloader;

        private readonly Stopwatch sw = new();

        public MainWindow()
        {
            InitializeComponent();

            webViewProvider = new DefaultWebViewProvider();
            webViewConfigurator = new DefaultWebViewConfigurator(webViewProvider);
            curseScraper = new DefaultCurseScraper(logger, webViewProvider);
            webViewDownloader = new DefaultWebViewDownloader(logger, webViewProvider);

            Loaded += MainWindow_Loaded;
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            var env = await WebViewHelper.CreateEnvironmentAsync();
            await webView.EnsureCoreWebView2Async(env);

            webViewProvider.SetWebView(webView.CoreWebView2);
            webViewConfigurator.SetDownloadFolder(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "TestDownloads"));
            webViewConfigurator.EnsureDownloadFolderExists();

            //webView.CoreWebView2.DownloadStarting += CoreWebView2_DownloadStarting;
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            await webViewConfigurator.ClearDownloadFolderAsync();

            sw.Restart();

            if (sender is Button button)
            {
                if (button.Content.ToString() == "Start1")
                {
                    webView.CoreWebView2.Navigate("https://www.curseforge.com/wow/addons/raiderio/download");
                }

                if (button.Content.ToString() == "Start2")
                {
                    IEnumerable<string> addonUrls = [
                        "https://www.curseforge.com/wow/addons/deadly-boss-mods",
                        "https://www.curseforge.com/wow/addons/details",
                        "https://www.curseforge.com/wow/addons/groupfinderflags",
                        "https://www.curseforge.com/wow/addons/raiderio",
                        "https://www.curseforge.com/wow/addons/tomtom",
                        "https://www.curseforge.com/wow/addons/weakauras-2"
                    ];

                    progressBar.Value = 0;
                    progressBar.Maximum = addonUrls.Count();

                    /*
                    List<string> downloadUrls = [];
                    foreach (var addonUrl in addonUrls)
                    {
                        var addonName = CurseHelper.GetAddonSlugNameFromAddonPageUrl(addonUrl);
                        textBlock.Text = $"Fetch {addonName}";

                        var downloadUrl = await curseScraper.GetAddonDownloadUrlAsync(addonUrl);
                        downloadUrls.Add(downloadUrl);

                        progressBar.Value++;
                    }
                    */

                    var downloadUrls = await GetDownloadUrlsAsync(addonUrls, new Progress<string>(p =>
                    {
                        progressBar.Value++;
                        textBlock.Text = $"Fetch {CurseHelper.GetAddonSlugNameFromAddonPageUrl(p)}";
                    }));

                    sw.Stop();
                    MessageBox.Show($"Fetch finished. Time (in ms): {sw.ElapsedMilliseconds}");

                    sw.Restart();
                    progressBar.Value = 0;
                    textBlock.Text = "Download...";

                    /*
                    var downloader = new DefaultWebViewDownloaderEAP(logger, webViewProvider);
                    
                    downloader.DownloadCompleted += (s, e) =>
                    {
                        sw.Stop();
                        MessageBox.Show($"Download finished. Time (in ms): {sw.ElapsedMilliseconds}");
                    };

                    downloader.DownloadProgressChanged += (s, e) =>
                    {
                        progressBar.Value++;
                    };
                    
                    downloader.DownloadAsync(downloadUrls, webViewConfigurator.GetDownloadFolder());
                    */

                    //MessageBox.Show(string.Join(", ", downloadUrls));

                    /*
                    var downloader = new DefaultWebViewDownloader(logger, webViewProvider);

                    var progress = new Progress<string>(p =>
                    {
                        progressBar.Value++;
                    });
                    */

                    progressBar.Minimum = 0;
                    progressBar.Maximum = downloadUrls.Count() * 100;
                    progressBar.Value = 0;

                    var percents = new ConcurrentDictionary<string, uint>();

                    await DownloadFilesAsync(downloadUrls, new Progress<DownloadProgress>(p =>
                    {
                        var fileName = Path.GetFileName(p.FilePath);
                        //textBlock.Text = $"Download {fileName} ({p.BytesReceived} / {p.TotalBytesToReceive})";
                        var percent = CalcDownloadPercent(p.ReceivedBytes, p.TotalBytes);


                        if (!percents.ContainsKey(fileName))
                        {
                            percents.TryAdd(fileName, percent);
                        }
                        else
                        {
                            percents[fileName] = percent;
                        }


                        var sum = percents.Sum(kvp => kvp.Value);
                        
                        progressBar.Value = sum;
                    }));

                    sw.Stop();
                    MessageBox.Show($"Download finished. Time (in ms): {sw.ElapsedMilliseconds}");

                }
            }
        }

        private async Task<IEnumerable<string>> GetDownloadUrlsAsync(IEnumerable<string> addonUrls, IProgress<string> progress, CancellationToken cancellationToken = default)
        {
            var tasks = addonUrls.Select(async addonUrl =>
            {
                var downloadUrl = await curseScraper.GetAddonDownloadUrlAsync(addonUrl, cancellationToken);
                progress.Report(addonUrl);
                return downloadUrl;
            });

            var downloadUrls = await Task.WhenAll(tasks);

            return downloadUrls;
        }

        private async Task<IEnumerable<string>> DownloadFilesAsync(IEnumerable<string> downloadUrls, IProgress<DownloadProgress> progress, CancellationToken cancellationToken = default)
        {
            var webView = webViewProvider.GetWebView();

            await webView.Profile.ClearBrowsingDataAsync(Microsoft.Web.WebView2.Core.CoreWebView2BrowsingDataKinds.DownloadHistory);
            
            var tasks = downloadUrls.Select(downloadUrl => webViewDownloader.DownloadFileAsync(downloadUrl, progress, cancellationToken));

            await Task.WhenAll(tasks);

            return downloadUrls;
        }

        private static byte CalcDownloadPercent(uint bytesReceived, uint bytesTotal)
        {
            // Doing casts inside try/catch block, just to be sure.

            try
            {
                double exact = (double)bytesReceived / bytesTotal * 100;
                byte rounded = (byte)Math.Round(exact);
                byte percent = rounded > 100 ? (byte)100 : rounded; // Cap it (just to be sure)

                return percent;
            }
            catch
            {
                return 0;
            }
        }
    }
}
