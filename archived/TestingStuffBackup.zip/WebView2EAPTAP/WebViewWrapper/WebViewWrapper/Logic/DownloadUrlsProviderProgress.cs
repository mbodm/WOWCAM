﻿namespace WebViewWrapper.Logic
{
    public sealed record DownloadUrlsProviderProgress(string AddonSlugName, string AddonPageUrl, string AddonDownloadUrl);
}
