using System.Diagnostics;
using System.Text.Json;
using Microsoft.Web.WebView2.Core;

namespace CurseTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textBox1.Text = "https://www.curseforge.com/wow/addons/raiderio/download";
            SetWpfButtonBehaviour();
            webView21.CoreWebView2InitializationCompleted += WebView21_CoreWebView2InitializationCompleted;
        }


        private async void button1_Click(object sender, EventArgs e)
        {
            //using var client = new HttpClient();
            //using var response = await client.GetAsync(textBox1.Text);
            //var content = await response.Content.ReadAsStringAsync();
            //return;

            List<string> urls = [
                "https://www.curseforge.com/wow/addons/raiderio/download",
                "https://www.curseforge.com/wow/addons/weakaura/download",
                "https://www.curseforge.com/wow/addons/recount/download"
            ];
            
            foreach (var url in urls)
            {
                var url = $"https://www.curseforge.com/wow/search?page={i}&pageSize=50&sortBy=latest+update&class=addons";
                if (Uri.TryCreate(url, new UriCreationOptions(), out Uri? uri) && uri != null)
                {
                    await semaphore.WaitAsync();
                    webView21.Source = uri;
                }
            }

            return;

            //var uri = new Uri(textBox1.Text);

            //if (webView21.Source != null && webView21.Source.AbsoluteUri == uri.AbsoluteUri)
            //{
            //    webView21.Reload();
            //}
            //else
            //{
            //    webView21.Source = uri;
            //}
        }

        private void SetWpfButtonBehaviour()
        {
            var backColorDefault = Color.FromArgb(221, 221, 221);
            var backColorHover = Color.FromArgb(190, 230, 253);
            var backColorDown = Color.FromArgb(196, 229, 246);

            var borderColorDefault = Color.FromArgb(112, 112, 112);
            var borderColorHover = Color.FromArgb(60, 127, 177);
            var borderColorDown = Color.FromArgb(44, 98, 139);

            button1.ForeColor = Color.Black;
            button1.BackColor = backColorDefault;
            button1.FlatAppearance.MouseOverBackColor = backColorHover;
            button1.FlatAppearance.MouseDownBackColor = backColorDown;

            button1.FlatAppearance.BorderSize = 1;
            button1.FlatAppearance.BorderColor = borderColorDefault;

            button1.MouseEnter += (s, e) => button1.FlatAppearance.BorderColor = borderColorHover;
            button1.MouseLeave += (s, e) => button1.FlatAppearance.BorderColor = borderColorDefault;

            //button1.MouseDown += (s, e) =>
            //{
            //    button1.FlatAppearance.BorderColor = borderColorDown;
            //    button1.FlatAppearance.BorderSize = 1;
            //};


            //button1.MouseUp += (s, e) => button1.FlatAppearance.BorderColor = borderColorDefault;
        }

        private void Button1_Paint(object sender, PaintEventArgs e)
        {
            //Pen pen = new(button1.FlatAppearance.BorderColor, 1);
            //Rectangle rectangle = new Rectangle(0, 0, Size.Width - 1, Size.Height - 1);
            //e.Graphics.DrawRectangle(pen, rectangle);
            //pen.Dispose();
        }

        private Stopwatch sw = new Stopwatch();

        private async void webView21_NavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            var url = e.Uri;
            var id = e.NavigationId;
            var isRedirected = e.IsRedirected;
            Debug.WriteLine($"{url}, {id}, {isRedirected}");

            sw.Restart();
        }

        private SemaphoreSlim semaphore = new SemaphoreSlim(1, 1);

        private async void webView21_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            //var html = await webView21.CoreWebView2.ExecuteScriptAsync("document.body.outerHTML");
            //var htmldecoded = JsonSerializer.Deserialize<object>(html);
            //var fuzz = htmldecoded?.ToString();

            sw.Stop();
            //MessageBox.Show(sw.ElapsedMilliseconds.ToString());
            Debug.WriteLine(sw.ElapsedMilliseconds);

            semaphore.Release();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            var env = await CoreWebView2Environment.CreateAsync(null, null, new CoreWebView2EnvironmentOptions() { AreBrowserExtensionsEnabled = false });
            await webView21.EnsureCoreWebView2Async(env);
        }

        private async void WebView21_CoreWebView2InitializationCompleted(object? sender, CoreWebView2InitializationCompletedEventArgs e)
        {
            //var pathToExtensionFolder = "C:\\Users\\Marcel\\AppData\\Local\\Microsoft\\Edge\\User Data\\Profile 2\\Extensions\\odfafepnkmbhccpbejgmiehpchacaeak\\1.62.0_0";
            var pathToExtensionFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "ublock");
            //await webView21.CoreWebView2.Profile.AddBrowserExtensionAsync(pathToExtensionFolder);
            var extensions = await webView21.CoreWebView2.Profile.GetBrowserExtensionsAsync();
            Debug.WriteLine(extensions.First().Name);

            //webView21.CoreWebView2.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
            webView21.CoreWebView2.WebResourceRequested += CoreWebView2_WebResourceRequested;
            webView21.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;



            //webView21.CoreWebView2.Settings.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0";
        }

        private void CoreWebView2_WebResourceRequested(object? sender, CoreWebView2WebResourceRequestedEventArgs e)
        {
            if (sender is CoreWebView2 webView)
            {
                var url = e.Request.Uri;
                var isPageUrl = url.StartsWith("https://www.curseforge.com/wow/addons/");
                var isInitialDownloadUrl = url.StartsWith("https://www.curseforge.com/api") && url.EndsWith("/download");

                if (e.ResourceContext == CoreWebView2WebResourceContext.Script)
                {
                    return;
                }

                if (isInitialDownloadUrl)
                {
                    webView.WebResourceRequested -= CoreWebView2_WebResourceRequested;
                    webView.RemoveWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
                }

                if (!isPageUrl && !isInitialDownloadUrl)
                {
                    e.Response = webView.Environment.CreateWebResourceResponse(null, 404, "Not found", null);
                }
            }
        }

        private void CoreWebView2_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void WebView21_ContentLoading(object sender, CoreWebView2ContentLoadingEventArgs e)
        {
            Debug.WriteLine("load some content");
        }
    }
}
