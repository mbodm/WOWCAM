﻿namespace WOWCAM.Core.Parts.Addons
{
    public enum AddonState
    {
        FetchFinished,
        DownloadProgress,
        DownloadFinished,
        DownloadFinishedBySmartUpdate,
        UnzipFinished
    }
}
