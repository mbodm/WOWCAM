﻿namespace WOWCAM.Core.Parts.Addons
{
    public interface IAddonsProcessing : IMultiAddonProcessor
    {
        // Facade
    }
}
