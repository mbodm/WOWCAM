﻿namespace WOWCAM.Core.Parts.Config
{
    public interface IConfigValidator
    {
        public void Validate(ConfigData configData);
    }
}
