﻿namespace WOWCAM.Helper
{
    public sealed record GitHubReleaseData(
        Version Version,
        string DownloadUrl,
        string FileName);
}
