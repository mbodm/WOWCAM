﻿using Microsoft.Web.WebView2.Core;

namespace WOWCAM.Core.Parts.WebView
{
    public interface IWebViewWrapper
    {
        public bool HideDownloadDialog { get; set; }

        Task<string> NavigateAndDownloadFileAsync(string downloadUrl, Func<CoreWebView2NavigationStartingEventArgs, bool>? navigationStartingInterception,
            IProgress<DownloadProgress>? progress = null, CancellationToken cancellationToken = default);
    }
}
