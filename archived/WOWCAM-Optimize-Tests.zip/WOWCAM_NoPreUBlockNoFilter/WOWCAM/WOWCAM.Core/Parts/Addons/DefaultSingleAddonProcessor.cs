﻿using Microsoft.Web.WebView2.Core;
using WOWCAM.Core.Parts.Settings;
using WOWCAM.Core.Parts.WebView;
using WOWCAM.Helper;

namespace WOWCAM.Core.Parts.Addons
{
    public sealed class DefaultSingleAddonProcessor(IAppSettings appSettings, IWebViewWrapper webViewWrapper, ISmartUpdateFeature smartUpdateFeature) : ISingleAddonProcessor
    {
        private readonly IAppSettings appSettings = appSettings ?? throw new ArgumentNullException(nameof(appSettings));
        private readonly IWebViewWrapper webViewWrapper = webViewWrapper ?? throw new ArgumentNullException(nameof(webViewWrapper));
        private readonly ISmartUpdateFeature smartUpdateFeature = smartUpdateFeature ?? throw new ArgumentNullException(nameof(smartUpdateFeature));

        public async Task ProcessAddonAsync(string addonPageUrl, IProgress<AddonProgress>? progress = default, CancellationToken cancellationToken = default)
        {
            // No ".ConfigureAwait(false)" here, cause otherwise the wrapped WebView's scheduler is not the correct one.
            // In general, the Microsoft WebView2 has to use the UI thread scheduler as its scheduler, to work properly.
            // Remember: This is also true for "ContinueWith()" blocks aka "code after await", even when it is a helper.

            var addonName = CurseHelper.GetAddonSlugNameFromAddonPageUrl(addonPageUrl);
            var downloadFolder = appSettings.Data.AddonDownloadFolder;
            var unzipFolder = appSettings.Data.AddonUnzipFolder;



















            var downloadUrl = addonPageUrl.Trim().TrimEnd('/') + "/download";
            //var downloadUrl = "https://ash-speed.hetzner.com/100MB.bin";
            //var downloadUrl = "https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/sdk-8.0.407-windows-x64-installer";

            string realDownloadUrl = string.Empty;
            string zipFile = string.Empty;
            bool zipFileExists = false;
            
            /*
            bool NavigationStartingInterception(CoreWebView2NavigationStartingEventArgs e)
            {
                if (e.Uri.StartsWith("https://mediafilez.forgecdn.net") && e.IsRedirected && e.Uri.EndsWith(".zip"))
                {
                    realDownloadUrl = e.Uri; 
                    
                    zipFile = realDownloadUrl.Split('/').Last().Split('/').First();
                    zipFileExists = smartUpdateFeature.AddonExists(addonName, realDownloadUrl, zipFile);
                    
                    return zipFileExists;
                }

                return false;
            }
            */

            var webViewWrapperProgress = new Progress<WebView.DownloadProgress>(p =>
            {
                var percent = CalcDownloadPercent(p.ReceivedBytes, p.TotalBytes);
                progress?.Report(new AddonProgress(AddonState.DownloadProgress, addonName, percent));
            });

            zipFile = await webViewWrapper.NavigateAndDownloadFileAsync(downloadUrl, null, webViewWrapperProgress, cancellationToken);

            /*
            if (Path.GetFileName(zipFileTemp) != zipFile)
            {
                throw new InvalidOperationException("WTF");
            }
            */
            
            progress?.Report(new AddonProgress(AddonState.DownloadFinished, addonName, 100));























            // Extract zip file

            cancellationToken.ThrowIfCancellationRequested();

            var zipFilePath = Path.Combine(downloadFolder, zipFile);

            if (!await UnzipHelper.ValidateZipFileAsync(zipFilePath, cancellationToken))
            {
                throw new InvalidOperationException($"It seems the addon zip file ('{zipFile}') is corrupted, cause zip file validation failed.");
            }

            await UnzipHelper.ExtractZipFileAsync(zipFilePath, unzipFolder, cancellationToken);

            progress?.Report(new AddonProgress(AddonState.UnzipFinished, addonName, 100));
        }

        private static byte CalcDownloadPercent(uint bytesReceived, uint bytesTotal)
        {
            // Doing casts inside try/catch block (just to be sure)

            try
            {
                var exact = (double)bytesReceived / bytesTotal;
                var exactPercent = exact * 100;
                var roundedPercent = (byte)Math.Round(exactPercent);
                var cappedPercent = roundedPercent > 100 ? (byte)100 : roundedPercent; // Cap it (just to be sure)

                return cappedPercent;
            }
            catch
            {
                return 0;
            }
        }
    }
}
