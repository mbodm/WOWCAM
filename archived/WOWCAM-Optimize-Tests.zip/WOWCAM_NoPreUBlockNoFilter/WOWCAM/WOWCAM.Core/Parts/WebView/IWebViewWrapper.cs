﻿using Microsoft.Web.WebView2.Core;

namespace WOWCAM.Core.Parts.WebView
{
    public interface IWebViewWrapper
    {
        public bool HideDownloadDialog { get; set; }

        Task NavigateToPageAsync(string pageUrl, CancellationToken cancellationToken = default);
        Task<string> NavigateToPageAndExecuteJavaScriptAsync(string pageUrl, string javaScript, CancellationToken cancellationToken = default);
        Task<string> NavigateAndDownloadFileAsync(string downloadUrl,
            Func<CoreWebView2NavigationStartingEventArgs, bool>? navigationStartingInterception = null,
            IProgress<DownloadProgress>? progress = null, CancellationToken cancellationToken = default);
    }
}
