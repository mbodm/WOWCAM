﻿using System.Diagnostics;
using System.Net;
using Microsoft.Web.WebView2.Core;
using WOWCAM.Core.Parts.Settings;
using WOWCAM.Core.Parts.WebView;
using WOWCAM.Helper;

namespace WOWCAM.Core.Parts.Addons
{
    public sealed class DefaultSingleAddonProcessor(IAppSettings appSettings, IWebViewWrapper webViewWrapper, ISmartUpdateFeature smartUpdateFeature) : ISingleAddonProcessor
    {
        private readonly IAppSettings appSettings = appSettings ?? throw new ArgumentNullException(nameof(appSettings));
        private readonly IWebViewWrapper webViewWrapper = webViewWrapper ?? throw new ArgumentNullException(nameof(webViewWrapper));
        private readonly ISmartUpdateFeature smartUpdateFeature = smartUpdateFeature ?? throw new ArgumentNullException(nameof(smartUpdateFeature));

        public async Task ProcessAddonAsync(string addonPageUrl, IProgress<AddonProgress>? progress = default, CancellationToken cancellationToken = default)
        {
            // No ".ConfigureAwait(false)" here, cause otherwise the wrapped WebView's scheduler is not the correct one.
            // In general, the Microsoft WebView2 has to use the UI thread scheduler as its scheduler, to work properly.
            // Remember: This is also true for "ContinueWith()" blocks aka "code after await", even when it is a helper.

            var addonName = CurseHelper.GetAddonSlugNameFromAddonPageUrl(addonPageUrl);
            var downloadFolder = appSettings.Data.AddonDownloadFolder;
            var unzipFolder = appSettings.Data.AddonUnzipFolder;





            var cookieContainer = new CookieContainer();
            var clientHandler = new HttpClientHandler
            {
                CookieContainer = cookieContainer,
                UseCookies = true
            };
            using var client = new HttpClient(clientHandler);
            client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36");
            var url = "https://www.curseforge.com/wow/addons/raiderio";
            using var response = await client.GetAsync(url);
            var content = await response.Content.ReadAsStringAsync();
            Debug.WriteLine(content);





            var downloadUrl = addonPageUrl.Trim().TrimEnd('/') + "/download";
            //var downloadUrl = "https://ash-speed.hetzner.com/100MB.bin";
            //var downloadUrl = "https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/sdk-8.0.407-windows-x64-installer";

            var webViewWrapperProgress = new Progress<WebView.DownloadProgress>(p =>
            {
                var percent = CalcDownloadPercent(p.ReceivedBytes, p.TotalBytes);
                progress?.Report(new AddonProgress(AddonState.DownloadProgress, addonName, percent));
            });

            var zipFile = await webViewWrapper.DownloadFileAsync(downloadUrl, webViewWrapperProgress, cancellationToken);

            progress?.Report(new AddonProgress(AddonState.DownloadFinished, addonName, 100));
























            // Extract zip file

            cancellationToken.ThrowIfCancellationRequested();

            var zipFilePath = Path.Combine(downloadFolder, zipFile);

            if (!await UnzipHelper.ValidateZipFileAsync(zipFilePath, cancellationToken))
            {
                throw new InvalidOperationException($"It seems the addon zip file ('{zipFile}') is corrupted, cause zip file validation failed.");
            }

            await UnzipHelper.ExtractZipFileAsync(zipFilePath, unzipFolder, cancellationToken);

            progress?.Report(new AddonProgress(AddonState.UnzipFinished, addonName, 100));
        }

        private static byte CalcDownloadPercent(uint bytesReceived, uint bytesTotal)
        {
            // Doing casts inside try/catch block (just to be sure)

            try
            {
                var exact = (double)bytesReceived / bytesTotal;
                var exactPercent = exact * 100;
                var roundedPercent = (byte)Math.Round(exactPercent);
                var cappedPercent = roundedPercent > 100 ? (byte)100 : roundedPercent; // Cap it (just to be sure)

                return cappedPercent;
            }
            catch
            {
                return 0;
            }
        }
    }
}
